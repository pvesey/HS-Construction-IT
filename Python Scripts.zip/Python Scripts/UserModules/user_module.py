

def show_letters_in_string(arg):
    for x in arg:
        print(x)


def reverse_letters_in_string(arg):
    return ''.join(reversed(arg))
