print('Hello World')

x = 10
y = 6
answer = x + y

print(x, y, (x+y), answer)

print('The calculated answer is:', answer)
