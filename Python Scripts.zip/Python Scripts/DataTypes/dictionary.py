# dictionary.py

# key value pair

my_dictionary = {"Alice": "085-123-4567", "Bob": "086-234-5678", "Eve": "087-345-6789"}

print(my_dictionary["Bob"])

my_dictionary_tuple = {"Chuck":("Effort", 20, 34.2) , "Dan":("Control", 26, 76.1) }

print(my_dictionary_tuple["Chuck"][1])
